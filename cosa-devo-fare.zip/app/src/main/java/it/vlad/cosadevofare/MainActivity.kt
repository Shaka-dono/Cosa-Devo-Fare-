package it.vlad.cosadevofare

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.provider.CalendarContract
import android.text.Html
import android.text.InputType
import android.text.TextUtils
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    companion object {
        const val MODEL = "claude-sonnet-5-5"
        const val PROMPT =
            "Sei un assistente che aiuta persone comuni a capire la burocrazia italiana. " +
            "Ti viene mostrata la foto di un documento (lettera, bolletta, multa, contratto, garanzia, avviso...). " +
            "Rispondi SOLO con un oggetto JSON, senza testo prima o dopo e senza backtick, con questi campi: " +
            "tipo (breve, es. 'Multa stradale'), " +
            "cosa_e (massimo 2 frasi semplici su cos'e' il documento), " +
            "cosa_fare (massimo 3 frasi con passi concreti da fare), " +
            "scadenza (data nel formato AAAA-MM-GG oppure null se non c'e'), " +
            "costo (importo con valuta, come testo, oppure null), " +
            "attenzione (una breve avvertenza se c'e' un rischio, per esempio sanzioni per ritardo, oppure null). " +
            "Usa un linguaggio semplice. Non inventare dati che non vedi nella foto. " +
            "Se la foto non e' leggibile o non e' un documento, metti tipo 'Non leggibile' e spiega in cosa_e. " +
            "La data di oggi e' "
    }

    private val prefs by lazy { getSharedPreferences("cdf", MODE_PRIVATE) }
    private var lastTitle = ""
    private var lastNotes = ""
    private var lastDeadline: LocalDate? = null

    private lateinit var btnCamera: Button
    private lateinit var btnGallery: Button
    private lateinit var btnCalendar: Button
    private lateinit var preview: ImageView
    private lateinit var progress: ProgressBar
    private lateinit var tvStatus: TextView
    private lateinit var resultBox: LinearLayout

    private val takePicture =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
            if (ok) analyze(photoUri())
        }

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) analyze(uri)
        }

    private fun photoUri(): Uri {
        val dir = File(cacheDir, "images").apply { mkdirs() }
        return FileProvider.getUriForFile(this, "$packageName.fileprovider", File(dir, "foto.jpg"))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnCamera = findViewById(R.id.btnCamera)
        btnGallery = findViewById(R.id.btnGallery)
        btnCalendar = findViewById(R.id.btnCalendar)
        preview = findViewById(R.id.preview)
        progress = findViewById(R.id.progress)
        tvStatus = findViewById(R.id.tvStatus)
        resultBox = findViewById(R.id.resultBox)

        btnCamera.setOnClickListener {
            if (apiKey().isEmpty()) askKey() else takePicture.launch(photoUri())
        }
        btnGallery.setOnClickListener {
            if (apiKey().isEmpty()) askKey() else pickImage.launch("image/*")
        }
        btnCalendar.setOnClickListener { addToCalendar() }
        findViewById<Button>(R.id.btnKey).setOnClickListener { askKey() }

        if (apiKey().isEmpty()) askKey()
    }

    private fun apiKey(): String = prefs.getString("key", "")?.trim() ?: ""

    private fun askKey() {
        val input = EditText(this).apply {
            hint = "sk-ant-..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setText(apiKey())
            setPadding(48, 32, 48, 32)
        }
        AlertDialog.Builder(this)
            .setTitle("Chiave API Anthropic")
            .setMessage("Incolla la tua chiave API. Resta salvata solo su questo telefono.")
            .setView(input)
            .setPositiveButton("Salva") { _, _ ->
                prefs.edit().putString("key", input.text.toString().trim()).apply()
            }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun setBusy(busy: Boolean) {
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        btnCamera.isEnabled = !busy
        btnGallery.isEnabled = !busy
        if (busy) {
            resultBox.visibility = View.GONE
            tvStatus.visibility = View.VISIBLE
            tvStatus.text = "Leggo il documento..."
        }
    }

    private fun analyze(uri: Uri) {
        val key = apiKey()
        if (key.isEmpty()) {
            askKey()
            return
        }
        setBusy(true)
        thread {
            try {
                val bmp = loadBitmap(uri)
                runOnUiThread {
                    preview.setImageBitmap(bmp)
                    preview.visibility = View.VISIBLE
                }
                val out = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
                val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                val result = callApi(key, b64)
                runOnUiThread { show(result) }
            } catch (e: Exception) {
                runOnUiThread {
                    setBusy(false)
                    tvStatus.visibility = View.VISIBLE
                    tvStatus.text = "Qualcosa e' andato storto: " + (e.message ?: "errore sconosciuto")
                }
            }
        }
    }

    private fun loadBitmap(uri: Uri): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2400) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp: Bitmap = contentResolver.openInputStream(uri)!!.use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: throw Exception("Immagine non leggibile")

        val degrees = contentResolver.openInputStream(uri)!!.use {
            when (ExifInterface(it).getAttributeInt(
                ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
            )) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        }
        if (degrees != 0f) {
            val m = Matrix().apply { postRotate(degrees) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val longSide = maxOf(bmp.width, bmp.height)
        if (longSide > 1568) {
            val s = 1568f / longSide
            bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * s).toInt(), (bmp.height * s).toInt(), true)
        }
        return bmp
    }

    private fun callApi(key: String, b64: String): JSONObject {
        val image = JSONObject()
            .put("type", "image")
            .put(
                "source", JSONObject()
                    .put("type", "base64")
                    .put("media_type", "image/jpeg")
                    .put("data", b64)
            )
        val text = JSONObject().put("type", "text").put("text", "Analizza questo documento.")
        val message = JSONObject()
            .put("role", "user")
            .put("content", JSONArray().put(image).put(text))
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 1000)
            .put("system", PROMPT + LocalDate.now().toString() + ".")
            .put("messages", JSONArray().put(message))

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 30000
        conn.readTimeout = 90000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-api-key", key)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val raw = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = try {
                JSONObject(raw).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                raw.take(200)
            }
            throw Exception("errore $code - $msg")
        }

        val content = JSONObject(raw).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val c = content.getJSONObject(i)
            if (c.optString("type") == "text") sb.append(c.getString("text"))
        }
        val clean = sb.toString().replace("```json", "").replace("```", "").trim()
        val start = clean.indexOf('{')
        val end = clean.lastIndexOf('}')
        if (start < 0 || end <= start) throw Exception("risposta non valida")
        return JSONObject(clean.substring(start, end + 1))
    }

    private fun JSONObject.str(k: String): String? {
        if (!has(k) || isNull(k)) return null
        val v = optString(k).trim()
        return if (v.isEmpty() || v == "null") null else v
    }

    private fun section(view: TextView, label: String, value: String?) {
        if (value == null) {
            view.visibility = View.GONE
            return
        }
        view.visibility = View.VISIBLE
        view.text = Html.fromHtml(
            "<b>" + TextUtils.htmlEncode(label) + "</b><br>" +
                TextUtils.htmlEncode(value).replace("\n", "<br>"),
            Html.FROM_HTML_MODE_LEGACY
        )
    }

    private fun show(r: JSONObject) {
        setBusy(false)
        tvStatus.visibility = View.GONE
        resultBox.visibility = View.VISIBLE

        val tipo = r.str("tipo") ?: "Documento"
        val cosaE = r.str("cosa_e")
        val cosaFare = r.str("cosa_fare")
        val costo = r.str("costo")
        val attenzione = r.str("attenzione")
        val deadline = try {
            r.str("scadenza")?.let { LocalDate.parse(it) }
        } catch (e: Exception) {
            null
        }

        findViewById<TextView>(R.id.tvTipo).text = tipo
        section(findViewById(R.id.tvCosaE), "Cos'e'", cosaE)
        section(findViewById(R.id.tvCosaFare), "Cosa devi fare", cosaFare)
        section(
            findViewById(R.id.tvScadenza), "Entro quando",
            deadline?.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
        )
        section(findViewById(R.id.tvCosto), "Quanto costa", costo)
        section(findViewById(R.id.tvAttenzione), "Attenzione", attenzione)

        lastTitle = tipo
        lastNotes = cosaFare ?: ""
        lastDeadline = deadline
        btnCalendar.visibility = if (deadline != null) View.VISIBLE else View.GONE
    }

    private fun addToCalendar() {
        val d = lastDeadline ?: return
        val begin = d.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        val intent = Intent(Intent.ACTION_INSERT)
            .setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, "Scadenza: $lastTitle")
            .putExtra(CalendarContract.Events.DESCRIPTION, lastNotes)
            .putExtra(CalendarContract.EXTRA_EVENT_ALL_DAY, true)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, begin + 86_400_000L)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Nessuna app calendario trovata", Toast.LENGTH_LONG).show()
        }
    }
}
